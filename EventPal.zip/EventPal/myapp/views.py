from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from .forms import EventForm
from .models import Event, RSVP
from django.db.models import Q
from django.http import Http404
from django.contrib import messages
from django.http import HttpResponseForbidden

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home_view(request):
    return render(request, 'home.html')

@login_required
def create_event_view(request):
    if request.method == 'POST':
        form = EventForm(request.POST, request.FILES)
        if form.is_valid():
            event = form.save(commit=False)
            event.created_by = request.user
            event.save()
            return redirect('event_list')
    else:
        form = EventForm()
    return render(request, 'create_event.html', {'form':form})

@login_required
def edit_event_view(request, event_id):
    event = get_object_or_404(Event, id=event_id, created_by=request.user)

    if request.method == 'POST':
        form = EventForm(request.POST, request.FILES, instance=event)
        if form.is_valid():
            form.save()
            return redirect('event_list')
    else:
        form = EventForm(instance=event)

    return render(request, 'edit_event.html', {'form': form, 'event': event})

@login_required
def event_list_view(request):
    user = request.user
    filter_option = request.GET.get('filter', 'all')
    if filter_option == 'all':
        events = Event.objects.filter(Q(created_by=user) | Q(rsvp__user=user)).distinct()
    elif filter_option == 'public':
        events = Event.objects.filter(is_public=True)
    elif filter_option == 'private':
        events = Event.objects.filter(is_public=False, created_by=request.user)

    return render(request, 'event_list.html', {
        'events': events.order_by('date'),
        'filter_option': filter_option
    })

def public_event_list_view(request):
    events = Event.objects.filter(is_public=True).order_by('date')
    return render(request, 'public_events.html', {'events': events})    

def event_detail_view(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    if not event.is_public and event.created_by != request.user:
        raise Http404("This event is private.")
    
    user_rsvped = False
    if request.user.is_authenticated:
        user_rsvped = RSVP.objects.filter(user=request.user, event=event).exists()

    return render(request, 'event_detail.html', {'event':event, 'user_rsvped':user_rsvped})

def landing_page(request):
    if request.user.is_authenticated:
        return redirect('home')

    recent_public = Event.objects.filter(is_public=True).order_by('-date')[:5]
    return render(request, 'landing.html', {'events': recent_public})

def rsvp_event_view(request, event_id):
    event = get_object_or_404(Event, id=event_id)

    if not event.is_public and event.created_by != request.user:
        return HttpResponseForbidden("You can't RSVP to a private event you don't own.")

    RSVP.objects.get_or_create(user=request.user, event=event)
    return redirect('event_detail', event_id=event.id)

def cancel_rsvp_view(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    rsvp = RSVP.objects.filter(user=request.user, event=event).first()
    if rsvp:
        rsvp.delete()
    return redirect('event_detail', event_id=event.id)

def delete_event_view(request, event_id):
    event = get_object_or_404(Event, id=event_id)

    if request.user != event.created_by:
        return HttpResponseForbidden("You are not allowed to delete this event.")

    if request.method == "POST":
        event.delete()
        messages.success(request, "Event deleted successfully.")
        return redirect('event_list')

    return render(request, 'delete_event.html', {'event': event})
















