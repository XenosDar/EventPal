from django.urls import path
from . import views

urlpatterns = [
	path('register/', views.register_view, name='register'),
	path('login/', views.login_view, name='login'),
	path('logout/', views.logout_view, name='logout'),
	path('', views.home_view, name='home'),
	path('events/', views.event_list_view, name='event_list'),
	path('events/create/', views.create_event_view, name='create_event'),
	path('events/<int:event_id>/edit/', views.edit_event_view, name='edit_event'),
	path('events/public/', views.public_event_list_view, name='public_events'),
	path('events/<int:event_id>/', views.event_detail_view, name='event_detail'),
	path('', views.landing_page, name='landing'),
	path('events/<int:event_id>/rsvp/', views.rsvp_event_view, name='rsvp_event'),
	path('events/<int:event_id>/cancel_rsvp/', views.cancel_rsvp_view, name='cancel_rsvp'),
	path('events/<int:event_id>/delete/', views.delete_event_view, name='delete_event'),
]


